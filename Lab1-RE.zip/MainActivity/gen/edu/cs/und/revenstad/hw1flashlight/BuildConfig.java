/** Automatically generated file. DO NOT MODIFY */
package edu.cs.und.revenstad.hw1flashlight;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}