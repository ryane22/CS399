/** Automatically generated file. DO NOT MODIFY */
package edu.cs.und.revenstad.lab5todo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}